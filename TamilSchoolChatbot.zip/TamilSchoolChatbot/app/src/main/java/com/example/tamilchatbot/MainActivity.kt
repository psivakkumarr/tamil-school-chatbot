
package com.example.tamilchatbot

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.*

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private val client = OkHttpClient()
    private val apiKey = "YOUR_OPENAI_API_KEY"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tts = TextToSpeech(this, this)

        val subjectSpinner = findViewById<Spinner>(R.id.subjectSpinner)
        val inputText = findViewById<EditText>(R.id.inputText)
        val sendBtn = findViewById<Button>(R.id.sendBtn)
        val resultView = findViewById<TextView>(R.id.resultView)

        val subjects = arrayOf("பாடம் தேர்வு செய்யவும்","தமிழ்","கணிதம்","அறிவியல்","சமூக அறிவியல்")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, subjects)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        subjectSpinner.adapter = adapter

        sendBtn.setOnClickListener {
            val userMessage = inputText.text.toString()
            val subject = subjectSpinner.selectedItem.toString()

            val fullPrompt = "பாடம்: $subject \n மாணவர் கேள்வி: $userMessage"
            callOpenAI(fullPrompt) { reply ->
                runOnUiThread {
                    resultView.text = reply
                    speakText(reply)
                }
            }
        }
    }

    private fun callOpenAI(prompt: String, callback: (String) -> Unit) {
        val url = "https://api.openai.com/v1/chat/completions"

        val json = JSONObject()
        json.put("model", "gpt-3.5-turbo")
        val messages = JSONArray()
        messages.put(
            JSONObject().put("role", "system")
                .put("content", "நீ பள்ளி மாணவர்களுக்கு தமிழில் உதவும் உதவியாளன் ஆக இருக்கிறாய்.")
        )
        messages.put(JSONObject().put("role", "user").put("content", prompt))
        json.put("messages", messages)

        val body = RequestBody.create(
            MediaType.parse("application/json"),
            json.toString()
        )
        val request = Request.Builder()
            .url(url)
            .post(body)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("OpenAI", "Error: ${e.message}")
                callback("பிழை ஏற்பட்டது!")
            }

            override fun onResponse(call: Call, response: Response) {
                response.body()?.string()?.let {
                    val jsonResponse = JSONObject(it)
                    val reply = jsonResponse.getJSONArray("choices")
                        .getJSONObject(0).getJSONObject("message")
                        .getString("content")
                    callback(reply.trim())
                }
            }
        })
    }

    private fun speakText(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("ta", "IN")
        }
    }

    override fun onDestroy() {
        if(::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
