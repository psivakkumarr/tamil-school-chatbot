# Tamil School Chatbot

A Tamil-language Android chatbot app for school subject assistance using GPT-4.